package com.thb.employee.department;

import org.springframework.data.repository.Repository;

import java.util.List;

public interface DepartmentRepository extends Repository<Department, Integer> {

    void delete(Department depart);

    List<Department> findAll();

    Department findOne(int id);

    Department save(Department depart);
}

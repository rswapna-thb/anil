package com.thb.employee.department;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@RequestMapping({"/api"})
@RequestMapping("/Depat")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping
    public Department create(@RequestBody Department depart){
        return departmentService.create(depart);
    }

    @GetMapping(path = {"/{id}"})
    public Department findOne(@PathVariable("id") int id){
        return departmentService.findById(id);
    }

    @PutMapping(path = {"/{id}"})
    public Department update(@PathVariable("id") int id, @RequestBody Department depart){
    	depart.setId(id);
        return departmentService.update(depart);
    }

    @DeleteMapping(path ={"/{id}"})
    public Department delete(@PathVariable("id") int id) {
        return departmentService.delete(id);
    }

    @GetMapping
    public List<Department> findAll(){
        return departmentService.findAll();
    }
}

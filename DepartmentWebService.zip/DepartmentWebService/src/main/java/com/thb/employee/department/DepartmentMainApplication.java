package com.thb.employee.department;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartmentMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentMainApplication.class, args);
	}
}
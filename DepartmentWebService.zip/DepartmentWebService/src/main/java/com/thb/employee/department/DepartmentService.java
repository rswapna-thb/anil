package com.thb.employee.department;

import java.util.List;

public interface DepartmentService {

    Department create(Department depart);

    Department delete(int id);

    List<Department> findAll();

    Department findById(int id);

    Department update(Department depart);
}

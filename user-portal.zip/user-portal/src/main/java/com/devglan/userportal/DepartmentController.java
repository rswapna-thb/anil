package com.devglan.userportal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@RequestMapping({"/api"})
@RequestMapping("/Depat")
public class DepartmentController {

    @Autowired
    private DepartmentService userService;

    @PostMapping
    public Department create(@RequestBody Department user){
        return userService.create(user);
    }

    @GetMapping(path = {"/{id}"})
    public Department findOne(@PathVariable("id") int id){
        return userService.findById(id);
    }

    @PutMapping(path = {"/{id}"})
    public Department update(@PathVariable("id") int id, @RequestBody Department user){
        user.setId(id);
        return userService.update(user);
    }

    @DeleteMapping(path ={"/{id}"})
    public Department delete(@PathVariable("id") int id) {
        return userService.delete(id);
    }

    @GetMapping
    public List<Department> findAll(){
        return userService.findAll();
    }
}

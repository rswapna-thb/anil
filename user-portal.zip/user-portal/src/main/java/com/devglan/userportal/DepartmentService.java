package com.devglan.userportal;

import java.util.List;

public interface DepartmentService {

    Department create(Department user);

    Department delete(int id);

    List<Department> findAll();

    Department findById(int id);

    Department update(Department user);
}

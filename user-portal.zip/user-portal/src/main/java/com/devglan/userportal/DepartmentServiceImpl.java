package com.devglan.userportal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentRepository repository;

    @Override
    public Department create(Department user) {
        return repository.save(user);
    }

    @Override
    public Department delete(int id) {
        Department user = findById(id);
        if(user != null){
            repository.delete(user);
        }
        return user;
    }

    @Override
    public List<Department> findAll() {
        return repository.findAll();
    }

    @Override
    public Department findById(int id) {
        return repository.findOne(id);
    }

    @Override
    public Department update(Department user) {
        return repository.save(user);
    }
}
